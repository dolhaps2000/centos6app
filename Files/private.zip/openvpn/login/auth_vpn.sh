#!/bin/bash
username=`head -n1 $1 | tail -1`   
password=`head -n2 $1 | tail -1`
#Database Credentials#
HOST='sql205.byethost.com'
USER='b13_24799985'
PASS='2lnw38jppz9t8eqw'
DB='b13_24799985_panel'
#Database Credentials#
SQL="user_name='$username' AND auth_vpn=md5('$password') AND is_validated='1' AND is_active='1' AND private_duration > '0' "
Query="SELECT user_name FROM users WHERE $SQL"
auth_vpn=`mysql -u $USER -p$PASS -D $DB -h $HOST -sN -e "$Query"`
if [ "$auth_vpn" == "$username" ]; then
echo "user : $username"
echo "authentication ok."
exit 0
else
echo "authentication failed."
exit 1
fi