#!/bin/bash
username=`head -n1 $1 | tail -1`   
password=`head -n2 $1 | tail -1`
#Database Credentials#
HOST='localhost'
USER='id11603788_fordsenpaiuser'
PASS='2lnw38jppz9t8eqw'
DB='id11603788_fordsenpainame'
#Database Credentials#
SQL="user_name='$username' AND auth_vpn=md5('$password') AND is_validated='1' AND is_active='1' AND duration > '0' "
Query="SELECT user_name FROM users WHERE $SQL"
auth_vpn=`mysql -u $USER -p$PASS -D $DB -h $HOST -sN -e "$Query"`
if [ "$auth_vpn" == "$username" ]; then
echo "user : $username"
echo "authentication ok."
exit 0
else
echo "authentication failed."
exit 1
fi
